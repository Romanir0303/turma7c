class Itau {

// main é o metodo inicial de qualquer aplicacao Java
public          static      void    main(String[] args){

System.out.print("Hello World!!!"); //exibe uma mensagem na tela

} // fecha o metodo main()

} // fecha a classe Itau