import javax.swing.JOptionPane;
class DecisaoComposta2{

public static void main(String args[]){
float saldo = Float.parseFloat(JOptionPane.showInputDialog("Digite o saldo"));
if (saldo<0){
	System.out.println("Sua conta está negativa!");
}else if (saldo>=1000){
	System.out.println("Estah sobrando dinheiro");	
}else {
	System.out.println("Sua conta é normal");	
}

System.out.println("Até logo!");
}
}